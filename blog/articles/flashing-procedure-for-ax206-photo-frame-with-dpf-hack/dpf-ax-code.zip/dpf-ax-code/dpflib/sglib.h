#include <stdint.h>


/* generic device wrapper: */

const char* dev_errstr(int error);


/* generic SCSI device stuff: */

#define DIR_IN  0
#define DIR_OUT 1


/* Special functions */




