//
// Type: sevendayshop_pebble
//
// Status: supported
// Credit: By superelchi, thx daveg
// Date: 2012-10-19
// Url: http://www.7dayshop.com/7dayshop-pebble-digital-photo-frame-1-5-tft-keyring-version-silver-irresistible-price
// 
// The CRCs identify.py detected - in the form "OpenWin CRC", "Init(Tbl) CRC"
// CRC: 0x58ff1144, 0x93cf2b3e
//
// 
#define LCD_WIDTH  128L
#define LCD_HEIGHT 128L
#define LCD_CONTROLLER_CUSTOM
//No detectable Lcd_contrast routine in fw - contrast setting disabled
//#define LCD_DEFAULT_CONTRAST_VALUE 7
#define LCD_DEFAULT_BRIGHTNESS_VALUE 20
