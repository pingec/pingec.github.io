// Type: delightdigi_black
// Comment: From ebay seller delight-digi
//
// Status: supported
// Credit: By superelchi, thx rotitude
// Date: 2012-04-22
// 
// The CRCs identify.py detected - in the form "OpenWin CRC", "Init(Tbl) CRC"
// CRC: 0xdda9c297, 0xda6ee4c3
//
// 
#define LCD_WIDTH  128L
#define LCD_HEIGHT 128L
#define LCD_CONTROLLER_CUSTOM
#define LCD_DEFAULT_CONTRAST_VALUE 7
#define LCD_DEFAULT_BRIGHTNESS_VALUE 21
// Contrast adjustable in menu
#define LCD_USER_ADJUSTABLE_CONTRAST 1
