// Type: linkdelight_3
// Comment: Variation of linkdelight
//
// Status: supported
// Credit: By superelchi, thx ax206geek, m_K_o
// Date: 2012-10-16
// Url: http://www.ebay.de/itm/260978964426?ssPageName=STRK:MEWNX:IT&_trksid=p3984.m1439.l2649
// 
// The CRCs identify.py detected - in the form "OpenWin CRC", "Init(Tbl) CRC"
// CRC: 0xea938e74, 0xdfce317f
//
// 
#define LCD_WIDTH  320L
#define LCD_HEIGHT 240L
#define LCD_CONTROLLER_CUSTOM
#define LCD_DEFAULT_BRIGHTNESS_VALUE 20
#define LCD_DEFAULT_CONTRAST_VALUE 5
