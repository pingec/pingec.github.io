//
// Type: taobao
// Comment: Also used by linkdelight.
//
// Status: supported
// Credit: By superelchi (thx cuckoohello)
// Date: 2013-01-05
// Url: http://item.taobao.com/item.htm?id=10380777914
// 
// The CRCs identify.py detected - in the form "OpenWin CRC", "Init(Tbl) CRC"
// CRC: 0x83dc7e28, 0x693ec116
//
// 
#define LCD_WIDTH  320L
#define LCD_HEIGHT 240L
#define LCD_CONTROLLER_CUSTOM
#define LCD_BACKLIGHT_HIGH
#define LCD_DEFAULT_CONTRAST_VALUE 5
#define LCD_DEFAULT_BRIGHTNESS_VALUE 13
// No useful info for user contrast adjust
//#define LCD_USER_ADJUSTABLE_CONTRAST 1
