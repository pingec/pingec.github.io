// Type: linkdelight_5
//
// Status: supported
// Credit: By superelchi
// Url: http://www.ebay.de/itm/ws/eBayISAPI.dll?ViewItem&item=110897096126
// Comment: Another variation of linkdelight
//
// The CRCs identify.py detected - in the form "OpenWin CRC", "Init(Tbl) CRC"
// CRC: 0x7dafdaf2, 0xaf2470d2
//
// 
#define LCD_WIDTH  320L
#define LCD_HEIGHT 240L
#define LCD_CONTROLLER_CUSTOM
#define LCD_BACKLIGHT_HIGH
#define LCD_DEFAULT_CONTRAST_VALUE 4
#define LCD_DEFAULT_BRIGHTNESS_VALUE 15
