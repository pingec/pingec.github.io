//
// Type: acme_2
// Comment: Unknown manufacturer
//
// Status: supported
// Credit: By superelchi, thx ax206geek, norefall
// Date: 2012-10-10
// 
// The CRCs identify.py detected - in the form "OpenWin CRC", "Init(Tbl) CRC"
// CRC: 0xedfb67dd, 0x244ad3c2
//
// 
#define LCD_WIDTH  128L
#define LCD_HEIGHT 128L
#define LCD_CONTROLLER_CUSTOM
//No detectable Lcd_contrast routine in fw - contrast setting disabled
//#define LCD_DEFAULT_CONTRAST_VALUE 6
#define LCD_DEFAULT_BRIGHTNESS_VALUE 21
