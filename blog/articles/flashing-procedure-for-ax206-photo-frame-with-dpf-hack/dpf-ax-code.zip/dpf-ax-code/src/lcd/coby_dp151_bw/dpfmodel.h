//
// Type: coby_dp151_bw
//
// Status: supported
// Credit: By superelchi, thx mrlinux
// Date: 2012-07-24
// Url: http://www.ebay.com/itm/280828187564
// 
// The CRCs identify.py detected - in the form "OpenWin CRC", "Init(Tbl) CRC"
// CRC: 0x111dedb7, 0x30097eb8
//
// 
#define LCD_WIDTH  128L
#define LCD_HEIGHT 128L
#define LCD_CONTROLLER_CUSTOM
#define LCD_DEFAULT_CONTRAST_VALUE 8
#define LCD_DEFAULT_BRIGHTNESS_VALUE 8
// Contrast adjustable in menu
#define LCD_USER_ADJUSTABLE_CONTRAST 1
