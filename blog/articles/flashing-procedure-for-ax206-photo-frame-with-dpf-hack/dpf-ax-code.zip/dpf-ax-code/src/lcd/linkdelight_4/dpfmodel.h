// Type: linkdelight_4
// Comment: Another variation of linkdelight
//
// Status: supported
// Credit: By superelchi, thx Solo0815
// Date: 2012-12-01
// Url: http://www.ebay.de/itm/260978964426?ssPageName=STRK:MEWNX:IT&_trksid=p3984.m1497.l2649
// 
// The CRCs identify.py detected - in the form "OpenWin CRC", "Init(Tbl) CRC"
// CRC: 0x66aebe1e, 0xc70ac3d2
//
// 
#define LCD_WIDTH  320L
#define LCD_HEIGHT 240L
#define LCD_CONTROLLER_CUSTOM
#define LCD_BACKLIGHT_HIGH
#define LCD_DEFAULT_BRIGHTNESS_VALUE 15
#define LCD_DEFAULT_CONTRAST_VALUE 4
