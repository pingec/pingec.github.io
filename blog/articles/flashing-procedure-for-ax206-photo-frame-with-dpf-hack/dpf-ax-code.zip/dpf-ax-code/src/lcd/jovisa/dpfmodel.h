// Type: jovisa
//
// Status: supported
// Credit: By superelchi, thx djJack
// Date: 2012-09-19
// Url: http://www.jovisa.biz/images/egg%20dpf%20or%20copy.jpg
// 
// The CRCs identify.py detected - in the form "OpenWin CRC", "Init(Tbl) CRC"
// CRC: 0xa27e3c21, 0xa0ff85ee
//
// 
#define LCD_WIDTH  128L
#define LCD_HEIGHT 128L
#define LCD_CONTROLLER_CUSTOM
#define LCD_ORIENTATION_RGB RGB_UP
#define DEFAULT_ORIENTATION ROT_LEFT
#define LCD_DEFAULT_BRIGHTNESS_VALUE 20
#define LCD_DEFAULT_CONTRAST_VALUE 5
// Contrast adjustable in menu
#define LCD_USER_ADJUSTABLE_CONTRAST 1
