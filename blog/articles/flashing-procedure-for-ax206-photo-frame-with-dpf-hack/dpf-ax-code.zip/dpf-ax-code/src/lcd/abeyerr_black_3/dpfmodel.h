//
// Type: abeyerr_black_3
//
// Status: supported
// Credit: By superelchi, thx joelbl
// Date: 2013-02-10
// Url: http://www.ebay.com/itm/280828187564
//
// The CRCs identify.py detected - in the form "OpenWin CRC", "Init(Tbl) CRC"
// CRC: 0xa27e3c21, 0x9ba027d9
//
// 
#define LCD_WIDTH  128L
#define LCD_HEIGHT 128L
#define LCD_CONTROLLER_CUSTOM
#define LCD_DEFAULT_CONTRAST_VALUE 2
#define LCD_DEFAULT_BRIGHTNESS_VALUE 15
// Contrast adjustable in menu
#define LCD_USER_ADJUSTABLE_CONTRAST 1
// Swap buttons
#define LCD_LRBUTTON_SWAP

