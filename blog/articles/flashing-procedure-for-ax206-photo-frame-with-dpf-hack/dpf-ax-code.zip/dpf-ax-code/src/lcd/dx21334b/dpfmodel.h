// Type: dx21334b
//
// Status: supported
// Credit: By superelchi
// Url: http://www.dealextreme.com/p/2-4-lcd-desktop-digital-photo-frame-and-calendar-27-picture-memory-storage-21334
// Url: http://www.ebay.de/itm/160792780280
// 
// The CRCs identify.py detected - in the form "OpenWin CRC", "Init(Tbl) CRC"
// CRC: 0xf4729795, 0xc70ac3d2
//
// 
#define LCD_WIDTH  320L
#define LCD_HEIGHT 240L
#define LCD_CONTROLLER_CUSTOM
#define LCD_BACKLIGHT_HIGH
#define LCD_DEFAULT_CONTRAST_VALUE 5
#define LCD_DEFAULT_BRIGHTNESS_VALUE 11
