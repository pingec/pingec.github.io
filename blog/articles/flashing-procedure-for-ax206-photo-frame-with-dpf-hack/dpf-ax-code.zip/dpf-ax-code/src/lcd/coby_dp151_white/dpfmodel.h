// Type: coby_dp151_white
//
// Status: supported
// Credit: By superelchi, thx donashe
// Date: 2012-05-14
// Url: http://www.frys.com/product/5439059
// 
// The CRCs identify.py detected - in the form "OpenWin CRC", "Init(Tbl) CRC"
// CRC: 0xd455d959, 0x1bb4578d
//
// 
#define LCD_WIDTH  128L
#define LCD_HEIGHT 128L
#define LCD_CONTROLLER_CUSTOM
// No detectable Lcd_contrast in fw - do not use contrast settings
//#define LCD_DEFAULT_CONTRAST_VALUE 8
#define LCD_DEFAULT_BRIGHTNESS_VALUE 8
