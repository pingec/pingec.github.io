// Type: veovision
//
// Status: supported
// Credit: By superelchi, thx ternyk
// Date: 2013-02-13
// URL: http://allegro.pl/breloczek-ramka-cyfrowa-16mb-lcd-1-5-brelok-i2966291376.html
//
// The CRCs identify.py detected - in the form "OpenWin CRC", "Init(Tbl) CRC"
// CRC: 0xd5efd5d9, 0xc537b07f
//
// 
#define LCD_WIDTH  128L
#define LCD_HEIGHT 128L
#define LCD_CONTROLLER_CUSTOM
#define LCD_DEFAULT_BRIGHTNESS_VALUE 20
#define LCD_DEFAULT_CONTRAST_VALUE 5
