//
// Type: intertronic
//
// Status: supported
// Credit: By superelchi, thx grouproot
// Date: 2012-10-22
// Url: http://www.interdiscount.ch/idshop/product/Spielwaren/873152_ER-324609050132160/INTERTRONIC_Digitaler_Bilderrahmen/detail.jsf
//
// The CRCs identify.py detected - in the form "OpenWin CRC", "Init(Tbl) CRC"
// CRC: 0xdda9c297, 0x59b5d4c0
//
// 
#define LCD_WIDTH  128L
#define LCD_HEIGHT 128L
#define LCD_CONTROLLER_CUSTOM
#define LCD_DEFAULT_CONTRAST_VALUE 5
#define LCD_DEFAULT_BRIGHTNESS_VALUE 5
// Contrast adjustable in menu
#define LCD_USER_ADJUSTABLE_CONTRAST 1
