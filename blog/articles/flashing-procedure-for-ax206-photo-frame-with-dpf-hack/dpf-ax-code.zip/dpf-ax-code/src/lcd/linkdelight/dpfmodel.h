// Type: linkdelight
//
// Status: supported
// Credit: By superelchi
//
// Url: http://www.ebay.de/itm/ws/eBayISAPI.dll?ViewItem&rd=1&item=260978964426&ssPageName=STRK:MEAFB:IT
// Url: http://www.ebay.de/itm/New-Mini-2-4-inch-Digital-Time-Day-Calendar-Alarm-Clock-Photo-Frame-POF16-/260883908884?pt=LH_DefaultDomain_0&hash=item3cbde48914#ht_4709wt_1046
// 
// The CRCs identify.py detected - in the form "OpenWin CRC", "Init(Tbl) CRC"
// CRC: 0x334bfc75, 0x30149543, 1, 1
//
// 
#define LCD_WIDTH  320L
#define LCD_HEIGHT 240L
#define LCD_CONTROLLER_CUSTOM
#define LCD_DEFAULT_CONTRAST_VALUE 6
#define LCD_DEFAULT_BRIGHTNESS_VALUE 21
