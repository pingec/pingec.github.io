//
// Type: avlabs_avl969s
//
// Status: supported
// Credit: By ax206geek
// Date: 2012-06-17
// Url: http://www.avlabs.net
// 
// The CRCs identify.py detected - in the form "OpenWin CRC", "Init(Tbl) CRC"
// CRC: 0x2c33f515, 0x31fac453
//
// 
#define LCD_WIDTH  128L
#define LCD_HEIGHT 128L
#define LCD_CONTROLLER_CUSTOM
#define LCD_DEFAULT_CONTRAST_VALUE 5
#define LCD_DEFAULT_BRIGHTNESS_VALUE 20
// Contrast adjustable in menu
#define LCD_USER_ADJUSTABLE_CONTRAST 1
