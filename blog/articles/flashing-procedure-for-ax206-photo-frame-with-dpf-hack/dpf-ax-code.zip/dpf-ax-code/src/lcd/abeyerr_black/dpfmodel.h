//
// Type: abeyerr_black
//
// Status: supported
// Credit: By superelchi, thx sairon
// Date: 2012-06-20
// 
// The CRCs identify.py detected - in the form "OpenWin CRC", "Init(Tbl) CRC"
// CRC: 0xfa7b6f9c, 0x7c0f30da
//
// 
#define LCD_WIDTH  128L
#define LCD_HEIGHT 128L
#define LCD_CONTROLLER_CUSTOM
#define LCD_DEFAULT_CONTRAST_VALUE 7
#define LCD_DEFAULT_BRIGHTNESS_VALUE 21
// Contrast adjustable in menu
#define LCD_USER_ADJUSTABLE_CONTRAST 1
