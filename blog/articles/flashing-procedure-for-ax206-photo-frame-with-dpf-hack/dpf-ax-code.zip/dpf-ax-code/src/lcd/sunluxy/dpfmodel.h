//
// Type: sunluxy
//
// Status: supported
// Credit: By superelchi, thx glb
// Date: 2013-01-27
// Url: http://www.amazon.fr/gp/product/B00AQV277C/
 
// The CRCs identify.py detected - in the form "OpenWin CRC", "Init(Tbl) CRC"
// CRC: 0xa27e3c21, 0xdd21d4a7
//
// 
#define LCD_WIDTH  128L
#define LCD_HEIGHT 128L
#define LCD_CONTROLLER_CUSTOM
#define LCD_DEFAULT_CONTRAST_VALUE 5
#define LCD_DEFAULT_BRIGHTNESS_VALUE 15
// Contrast adjustable in menu
#define LCD_USER_ADJUSTABLE_CONTRAST 1
