//
// Type: acme_1
// Comment: Unknown ebay seller
//
// Status: supported
// Credit: By superelchi, thx RedoX
// Date: 2012-07-24
// 
// The CRCs identify.py detected - in the form "OpenWin CRC", "Init(Tbl) CRC"
// CRC: 0xa27e3c21, 0xba9f3a43
//
// 
#define LCD_WIDTH  128L
#define LCD_HEIGHT 128L
#define LCD_CONTROLLER_CUSTOM
#define LCD_DEFAULT_CONTRAST_VALUE 4
#define LCD_DEFAULT_BRIGHTNESS_VALUE 20
// Contrast adjustable in menu
#define LCD_USER_ADJUSTABLE_CONTRAST 1
