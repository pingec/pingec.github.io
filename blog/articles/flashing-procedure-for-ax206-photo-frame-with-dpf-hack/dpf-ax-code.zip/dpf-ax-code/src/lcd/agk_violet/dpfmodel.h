//
// Type: agk_violet
//
// Status: supported
// 
// The CRCs identify.py detected - in the form "OpenWin CRC", "Init(Tbl) CRC"
// CRC: 0xd5efd5d9, 0x54cc8527
//
// 
#define LCD_WIDTH  128L
#define LCD_HEIGHT 128L
#define LCD_CONTROLLER_CUSTOM
//No detectable Lcd_contrast routine in fw - contrast setting disabled
//#define LCD_DEFAULT_CONTRAST_VALUE 4
#define LCD_DEFAULT_BRIGHTNESS_VALUE 20
