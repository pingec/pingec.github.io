/* Extra stuff for AX206
 *
 */


#define BYTE unsigned char

// Compatibility:
//

#define usbcon0 usbcon


