
#define LOG_SECTOR 0x3e0000
#define CONFIG_SECTOR 0x3d0000

//>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
//
// config.h NO LONGER USED FOR DEFINING TYPES!
// DEFINE NEW TYPES in lcd/$(TYPE)/dpfmodel.h!
//
//<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<

#include "dpfmodel.h"  //= "./lcd/$(TYPE)/dpfmodel.h"
